<?php

/**
 * Element Defaults: Icon List Item
 */

return array(
	'id'    => '',
	'class' => '',
	'style' => '',
	'title' => '',
	'type'  => ''
);