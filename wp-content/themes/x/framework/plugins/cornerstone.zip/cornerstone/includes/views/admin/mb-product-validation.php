<?php if ( false ) : ?>

  <p class="cs-validated"><strong>Congrats! Cornerstone is validated</strong>. Automatic updates are up and running.<br><input type="text" name="api_key"></p>

<?php else : ?>

  <p class="cs-not-validated"><strong>Uh oh! It looks like Cornerstone isn't validated</strong>. Product validation enables automatic updates.<br><input type="text" name="api_key"></p>

<?php endif;