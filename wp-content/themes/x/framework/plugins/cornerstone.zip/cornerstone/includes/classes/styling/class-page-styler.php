<?php

class Cornerstone_Page_Styler {

	public function __construct( $post_id ) {

		$reducer = new Cornerstone_Element_Reducer( $post_id );

	}


}